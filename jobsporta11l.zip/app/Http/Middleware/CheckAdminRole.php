<?php

namespace App\Http\Middleware;

use Closure;

class CheckAdminRole
{

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $admin = $request->user();
        $routeAction = $request->route()->getAction();
        $requiredRoles = isset($routeAction['allowed_roles']) ? $routeAction['allowed_roles'] : 'NONE';

        \Log::info("CheckAdminRole: Checking access for User ID: " . ($admin ? $admin->id : 'GUEST'));
        \Log::info("CheckAdminRole: Route requires: " . json_encode($requiredRoles));

        if (!$admin) {
            \Log::warning("CheckAdminRole: No admin user found.");
            return response()->view('admin.errors.401', [], 401);
        }

        // 1. Super Admin always allowed
        // 2. Managers always allowed (but still restricted by CheckPermission later)
        if ($admin->hasRole('SUPER_ADMIN') || $admin->is_manager) {
            \Log::info("CheckAdminRole: Access GRANTED (Super Admin or Manager).");
            return $next($request);
        }

        // Get the required roles from the route
        $roles = $this->getRequiredRoleForRoute($request->route());

        // 3. If no specific roles required, allow through
        if (!$roles) {
            \Log::info("CheckAdminRole: Access GRANTED (No roles required).");
            return $next($request);
        }

        // 4. Check if user has the specific required role
        if ($admin->hasRole($roles)) {
            \Log::info("CheckAdminRole: Access GRANTED (User has required role).");
            return $next($request);
        }

        // Fallback for custom active roles on "general" routes (SUB_ADMIN etc)
        $role = $admin->role()->first();
        if ($role && $role->is_active && !$role->is_system) {
            if (is_array($roles) && in_array('SUB_ADMIN', $roles)) {
                \Log::info("CheckAdminRole: Access GRANTED (Custom Role fallback for array).");
                return $next($request);
            }
            if ($roles == 'SUB_ADMIN') {
                \Log::info("CheckAdminRole: Access GRANTED (Custom Role fallback for string).");
                return $next($request);
            }
        }

        \Log::warning("CheckAdminRole: Access DENIED. User Roles: " . json_encode($admin->role()->pluck('role_name')) . " Required: " . json_encode($roles));
        return response()->view('admin.errors.401', [], 401);
    }

    private function getRequiredRoleForRoute($route)
    {
        $actions = $route->getAction();
        return isset($actions['allowed_roles']) ? $actions['allowed_roles'] : null;
    }

}
