<?php
/**
 * Yetkilendirme güncellemesi - Tek seferlik çalıştırma
 *
 * 1) Veritabanı: izin isimleri + rol-izin atamaları
 * 2) Dosyalar: CheckAdminRole, AllowedRoles, CheckPermission, IsActiveScope, LangScope,
 *    sidebar, company route, Admin.php (müdür CRM)
 *
 * Tarayıcıdan çalıştırmak için bu dosyayı PUBLIC klasörüne kopyalayın, sonra:
 *   https://site.com/update_permissions_once.php
 * Komut satırından: proje kökünde  php update_permissions_once.php
 *
 * İşlem bittikten sonra bu dosyayı sunucudan silin.
 */

// Laravel rotasından include edildiyse buffer/HTML ile oynamayalım
$inLaravel = function_exists('app');
// Beyaz ekranı önle: hata göster, tamponu kapat, hemen çıktı ver (sadece standalone web)
if (php_sapi_name() !== 'cli' && !$inLaravel) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    @set_time_limit(120);
    while (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: text/html; charset=utf-8');
    echo "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>Güncelleme</title></head><body><pre id=\"out\">";
    echo "Script başlatılıyor...\n";
    if (function_exists('flush')) { flush(); }
}

// Laravel zaten yüklü mü? (rota üzerinden include edildiyse)
$root = __DIR__;
if (basename($root) === 'public' && is_file($root . '/../vendor/autoload.php')) {
    $root = dirname($root);
}
$app = null;
if (function_exists('app')) {
    try {
        $application = app();
        if ($application instanceof \Illuminate\Contracts\Foundation\Application) {
            $app = $application;
            $root = $application->basePath();
        }
    } catch (Throwable $e) {
        // Laravel değil veya hata
    }
}
if ($app === null) {
    if (!is_file($root . '/vendor/autoload.php') || !is_file($root . '/bootstrap/app.php')) {
        $msg = "Hata: Laravel proje kökü bulunamadı. Bu dosyayı public/ klasörüne kopyalayıp tarayıcıdan açın veya proje kökünden php ile çalıştırın.";
        if (php_sapi_name() !== 'cli') {
            header('Content-Type: text/plain; charset=utf-8');
            echo $msg . "\n__DIR__=" . __DIR__ . "\nroot=" . $root;
        } else {
            echo $msg . "\n";
        }
        exit(1);
    }
    try {
        require $root . '/vendor/autoload.php';
        $app = require_once $root . '/bootstrap/app.php';
        $kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
        $kernel->bootstrap();
    } catch (Throwable $e) {
        if (php_sapi_name() !== 'cli') {
            header('Content-Type: text/plain; charset=utf-8');
            echo "Bootstrap hatası: " . $e->getMessage() . "\n\n" . $e->getTraceAsString();
        } else {
            echo "Bootstrap hatası: " . $e->getMessage() . "\n";
        }
        exit(1);
    }
}

use Illuminate\Support\Facades\DB;

$log = [];
function say($msg, array &$log) {
    $log[] = $msg;
    echo $msg . "\n";
}

try {
    say('=== Yetkilendirme güncellemesi başlıyor ===', $log);

    // 1) Eski izin isimlerini yeni formata güncelle
    $oldToNew = [
        'users.view' => 'view_users',
        'users.create' => 'create_users',
        'users.edit' => 'edit_users',
        'users.delete' => 'delete_users',
        'companies.view' => 'view_companies',
        'companies.create' => 'create_companies',
        'companies.edit' => 'edit_companies',
        'companies.delete' => 'delete_companies',
        'companies.verify' => 'verify_companies',
        'jobs.view' => 'view_jobs',
        'jobs.create' => 'create_jobs',
        'jobs.edit' => 'edit_jobs',
        'jobs.delete' => 'delete_jobs',
        'jobs.feature' => 'feature_jobs',
        'jobs.approve' => 'approve_jobs',
        'applications.view' => 'view_applications',
        'applications.edit' => 'edit_applications',
        'applications.delete' => 'delete_applications',
        'reports.view' => 'view_reports',
        'reports.export' => 'export_reports',
        'services.view' => 'view_services',
        'services.create' => 'create_services',
        'services.edit' => 'edit_services',
        'services.delete' => 'delete_services',
        'service_requests.view' => 'view_service_requests',
        'service_requests.edit' => 'manage_service_requests',
        'service_requests.delete' => 'manage_service_requests',
        'admin.users' => 'manage_admins',
        'admin.roles' => 'manage_roles',
        'admin.permissions' => 'manage_permissions',
        'admin.settings' => 'manage_settings',
    ];

    foreach ($oldToNew as $oldName => $newName) {
        if ($oldName !== $newName && DB::table('permissions')->where('name', $oldName)->exists()) {
            $oldPerm = DB::table('permissions')->where('name', $oldName)->first();
            $newPerm = DB::table('permissions')->where('name', $newName)->first();

            if ($newPerm) {
                if ($oldPerm && DB::getSchemaBuilder()->hasTable('role_permissions')) {
                    $roleIds = DB::table('role_permissions')->where('permission_id', $oldPerm->id)->pluck('role_id')->toArray();
                    foreach ($roleIds as $rid) {
                        DB::table('role_permissions')->updateOrInsert(
                            ['role_id' => $rid, 'permission_id' => $newPerm->id],
                            ['created_at' => now(), 'updated_at' => now()]
                        );
                    }
                    DB::table('role_permissions')->where('permission_id', $oldPerm->id)->delete();
                }
                DB::table('permissions')->where('id', $oldPerm->id)->delete();
                say("Birleştirildi: {$oldName} -> {$newName}", $log);
            } else {
                DB::table('permissions')->where('name', $oldName)->update(['name' => $newName]);
                say("Güncellendi: {$oldName} -> {$newName}", $log);
            }
        }
    }

    if (DB::table('permissions')->where('name', 'admin.reports')->exists()) {
        DB::table('permissions')->where('name', 'admin.reports')->delete();
        say('Silindi: admin.reports (çift kayıt)', $log);
    }

    // 2) Eksik izinleri ekle
    $newPermissions = [
        ['name' => 'view_orders', 'display_name' => 'Siparişleri Görüntüle', 'description' => 'Ödeme/sipariş geçmişini görüntüleme', 'group' => 'orders'],
        ['name' => 'manage_blog', 'display_name' => 'Blog Yönetimi', 'description' => 'Blog yazıları ve kategorileri yönetme', 'group' => 'content'],
        ['name' => 'manage_content', 'display_name' => 'İçerik Yönetimi', 'description' => 'Widget, sayfa ve içerik yönetimi', 'group' => 'content'],
        ['name' => 'manage_seo', 'display_name' => 'SEO Yönetimi', 'description' => 'SEO ayarlarını yönetme', 'group' => 'content'],
        ['name' => 'manage_security', 'display_name' => 'Güvenlik Ayarları', 'description' => 'Güvenlik ayarlarını yönetme', 'group' => 'admin'],
        ['name' => 'manage_campaigns', 'display_name' => 'Kampanya Yönetimi', 'description' => 'E-posta kampanyaları yönetme', 'group' => 'admin'],
        ['name' => 'manage_definitions', 'display_name' => 'Tanım Yönetimi', 'description' => 'Tanım modüllerini yönetme', 'group' => 'settings'],
        ['name' => 'manage_roles', 'display_name' => 'Rol Yönetimi', 'description' => 'Rolleri yönetme', 'group' => 'admin'],
        ['name' => 'manage_admins', 'display_name' => 'Yönetici Yönetimi', 'description' => 'Yönetici kullanıcıları yönetme', 'group' => 'admin'],
        ['name' => 'manage_settings', 'display_name' => 'Ayarları Yönet', 'description' => 'Site ayarlarını yönetme', 'group' => 'admin'],
        ['name' => 'view_automation', 'display_name' => 'Otomasyon Görüntüle', 'description' => 'Otomasyon ve eşleşmeleri görüntüleme', 'group' => 'automation'],
        ['name' => 'manage_automation', 'display_name' => 'Otomasyon Yönetimi', 'description' => 'Otomasyon kurallarını yönetme', 'group' => 'automation'],
        ['name' => 'manage_services', 'display_name' => 'Hizmet Yönetimi', 'description' => 'Hizmet ve kategorileri yönetme', 'group' => 'services'],
        ['name' => 'manage_service_requests', 'display_name' => 'Hizmet Talebi Yönetimi', 'description' => 'Hizmet taleplerini yönetme', 'group' => 'service_requests'],
        ['name' => 'approve_service_requests', 'display_name' => 'Hizmet Talebi Onaylama', 'description' => 'Hizmet taleplerini onaylama', 'group' => 'service_requests'],
        ['name' => 'manage_service_request_status', 'display_name' => 'Hizmet Talebi Durumu', 'description' => 'Hizmet talebi durumunu güncelleme', 'group' => 'service_requests'],
        ['name' => 'approve_caregiver_requests', 'display_name' => 'Bakıcı Talebi Onaylama', 'description' => 'Bakıcı taleplerini onaylama', 'group' => 'service_requests'],
        ['name' => 'manage_caregiver_request_status', 'display_name' => 'Bakıcı Talebi Durumu', 'description' => 'Bakıcı talebi durumunu güncelleme', 'group' => 'service_requests'],
        ['name' => 'view_crm', 'display_name' => 'CRM Görüntüle', 'description' => 'CRM ve personel aktivitelerini görüntüleme', 'group' => 'crm'],
        ['name' => 'manage_crm', 'display_name' => 'CRM Yönetimi', 'description' => 'CRM notları ve bildirimleri yönetme', 'group' => 'crm'],
        ['name' => 'view_pages', 'display_name' => 'Sayfaları Görüntüle', 'description' => 'CMS sayfalarını görüntüleme', 'group' => 'content'],
        ['name' => 'manage_pages', 'display_name' => 'Sayfa Yönetimi', 'description' => 'CMS sayfalarını yönetme', 'group' => 'content'],
        ['name' => 'view_blog', 'display_name' => 'Blog Görüntüle', 'description' => 'Blog içeriklerini görüntüleme', 'group' => 'content'],
        ['name' => 'manage_faqs', 'display_name' => 'SSS Yönetimi', 'description' => 'Sıkça sorulan soruları yönetme', 'group' => 'content'],
        ['name' => 'manage_videos', 'display_name' => 'Video Yönetimi', 'description' => 'Videoları yönetme', 'group' => 'content'],
        ['name' => 'manage_testimonials', 'display_name' => 'Referans Yönetimi', 'description' => 'Referansları yönetme', 'group' => 'content'],
        ['name' => 'manage_sliders', 'display_name' => 'Slider Yönetimi', 'description' => 'Sliderları yönetme', 'group' => 'content'],
        ['name' => 'manage_locations', 'display_name' => 'Konum Yönetimi', 'description' => 'Ülke, şehir, bölge yönetimi', 'group' => 'settings'],
        ['name' => 'view_packages', 'display_name' => 'Paketleri Görüntüle', 'description' => 'Paketleri görüntüleme', 'group' => 'packages'],
        ['name' => 'create_packages', 'display_name' => 'Paket Oluştur', 'description' => 'Yeni paket oluşturma', 'group' => 'packages'],
        ['name' => 'edit_packages', 'display_name' => 'Paket Düzenle', 'description' => 'Paket bilgilerini düzenleme', 'group' => 'packages'],
        ['name' => 'delete_packages', 'display_name' => 'Paket Sil', 'description' => 'Paket silme', 'group' => 'packages'],
        ['name' => 'manage_career_levels', 'display_name' => 'Kariyer Seviyesi Yönetimi', 'description' => 'Kariyer seviyelerini yönetme', 'group' => 'settings'],
        ['name' => 'view_settings', 'display_name' => 'Ayarları Görüntüle', 'description' => 'Site ayarlarını görüntüleme', 'group' => 'admin'],
        ['name' => 'view_caregivers', 'display_name' => 'Bakıcıları Görüntüle', 'description' => 'Bakıcı listesini görüntüleme', 'group' => 'caregivers'],
        ['name' => 'view_caregiver_categories', 'display_name' => 'Bakıcı Kategorileri', 'description' => 'Bakıcı kategorilerini görüntüleme', 'group' => 'caregivers'],
        ['name' => 'manage_caregiver_categories', 'display_name' => 'Bakıcı Türlerini Yönet', 'description' => 'Bakıcı kategorilerini yönetme', 'group' => 'caregivers'],
        ['name' => 'view_caregiver_requests', 'display_name' => 'Bakıcı Taleplerini Görüntüle', 'description' => 'Bakıcı taleplerini görüntüleme', 'group' => 'caregivers'],
        ['name' => 'view_service_categories', 'display_name' => 'Hizmet Kategorileri', 'description' => 'Hizmet kategorilerini görüntüleme', 'group' => 'services'],
        ['name' => 'view_service_addons', 'display_name' => 'Hizmet Eklentileri', 'description' => 'Hizmet eklentilerini görüntüleme', 'group' => 'services'],
    ];

    $now = date('Y-m-d H:i:s');
    $added = 0;
    foreach ($newPermissions as $p) {
        if (!DB::table('permissions')->where('name', $p['name'])->exists()) {
            DB::table('permissions')->insert([
                'name' => $p['name'],
                'display_name' => $p['display_name'],
                'description' => $p['description'],
                'group' => $p['group'],
                'is_active' => 1,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            $added++;
            say("Eklendi: {$p['name']}", $log);
        }
    }
    say("Toplam {$added} yeni izin eklendi.", $log);

    // 3) SUPER_ADMIN'e tüm izinleri ver
    $superAdmin = DB::table('roles')->where('role_name', 'SUPER_ADMIN')->first();
    if ($superAdmin) {
        $permissionIds = DB::table('permissions')->where('is_active', 1)->pluck('id')->toArray();
        $existing = DB::table('role_permissions')->where('role_id', $superAdmin->id)->pluck('permission_id')->toArray();
        $toInsert = array_diff($permissionIds, $existing);
        foreach ($toInsert as $pid) {
            DB::table('role_permissions')->insert([
                'role_id' => $superAdmin->id,
                'permission_id' => $pid,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
        say('SUPER_ADMIN rolüne ' . count($toInsert) . ' izin atandı.', $log);
    } else {
        say('Uyarı: SUPER_ADMIN rolü bulunamadı.', $log);
    }

    // 4) SUB_ADMIN varsayılan izinler
    $subAdmin = DB::table('roles')->where('role_name', 'SUB_ADMIN')->first();
    if ($subAdmin) {
        $names = [
            'view_users', 'edit_users', 'create_users', 'view_companies', 'edit_companies', 'view_jobs', 'edit_jobs',
            'approve_jobs', 'feature_jobs', 'view_reports', 'view_services', 'manage_services', 'view_service_requests',
            'manage_service_requests', 'approve_service_requests', 'manage_service_request_status',
            'view_automation', 'view_crm', 'manage_content', 'manage_blog', 'view_pages', 'manage_pages',
            'manage_faqs', 'manage_seo', 'view_packages', 'view_orders',
            'manage_definitions',
        ];
        $pids = DB::table('permissions')->whereIn('name', $names)->pluck('id')->toArray();
        $existing = DB::table('role_permissions')->where('role_id', $subAdmin->id)->pluck('permission_id')->toArray();
        $toInsert = array_diff($pids, $existing);
        foreach ($toInsert as $pid) {
            DB::table('role_permissions')->insert([
                'role_id' => $subAdmin->id,
                'permission_id' => $pid,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
        say('SUB_ADMIN rolüne ' . count($toInsert) . ' varsayılan izin atandı.', $log);
    }

    // 5) CALL_CENTER varsayılan izinler
    $callCenter = DB::table('roles')->where('role_name', 'CALL_CENTER')->first();
    if ($callCenter) {
        $names = [
            'view_users', 'edit_users', 'view_companies', 'edit_companies', 'view_jobs', 'edit_jobs',
            'view_service_requests', 'manage_service_requests', 'approve_service_requests', 'manage_service_request_status',
            'approve_caregiver_requests', 'manage_caregiver_request_status', 'view_automation', 'view_crm',
        ];
        $pids = DB::table('permissions')->whereIn('name', $names)->pluck('id')->toArray();
        $existing = DB::table('role_permissions')->where('role_id', $callCenter->id)->pluck('permission_id')->toArray();
        $toInsert = array_diff($pids, $existing);
        foreach ($toInsert as $pid) {
            DB::table('role_permissions')->insert([
                'role_id' => $callCenter->id,
                'permission_id' => $pid,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
        say('CALL_CENTER rolüne ' . count($toInsert) . ' varsayılan izin atandı.', $log);
    }

    // 6) Dosya güncellemeleri
    say('--- Dosya güncellemeleri ---', $log);

    $files = [
        'app/Http/Middleware/CheckAdminRole.php' => <<<'PHP'
<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class CheckAdminRole
{

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $admin = Auth::guard('admin')->user();

        if (config('app.debug')) {
            $routeAction = $request->route()->getAction();
            $requiredRoles = isset($routeAction['allowed_roles']) ? $routeAction['allowed_roles'] : 'NONE';
            \Log::debug("CheckAdminRole: Admin ID: " . ($admin ? $admin->id : 'GUEST') . ", route requires: " . json_encode($requiredRoles));
        }

        if (!$admin) {
            \Log::warning("CheckAdminRole: No admin user found.");
            return response()->view('admin.errors.401', [], 401);
        }

        // 1. Super Admin always allowed
        // 2. Managers always allowed (but still restricted by CheckPermission later)
        if ($admin->hasRole('SUPER_ADMIN') || $admin->is_manager) {
            return $next($request);
        }

        // Get the required roles from the route
        $roles = $this->getRequiredRoleForRoute($request->route());

        // 3. If no specific roles required, allow through
        if (!$roles) {
            return $next($request);
        }

        // 4. Check if user has the specific required role
        if ($admin->hasRole($roles)) {
            return $next($request);
        }

        // Fallback for custom active roles on "general" routes (SUB_ADMIN etc)
        $role = $admin->role()->first();
        if ($role && $role->is_active && !$role->is_system) {
            if (is_array($roles) && in_array('SUB_ADMIN', $roles)) {
                return $next($request);
            }
            if ($roles == 'SUB_ADMIN') {
                return $next($request);
            }
        }

        \Log::warning("CheckAdminRole: Access DENIED. Admin ID: " . $admin->id . ", roles: " . json_encode($admin->role()->pluck('role_name')) . ", required: " . json_encode($roles));
        return response()->view('admin.errors.401', [], 401);
    }

    private function getRequiredRoleForRoute($route)
    {
        $actions = $route->getAction();
        return isset($actions['allowed_roles']) ? $actions['allowed_roles'] : null;
    }

}
PHP
,
        'app/Http/Middleware/CheckPermission.php' => <<<'PHP'
<?php

namespace App\Http\Middleware;

use Closure;
use Auth;

class CheckPermission
{
    /**
     * Handle an incoming request.
     *
     * Check if the authenticated admin has the required permission.
     * SUPER_ADMIN bypasses all permission checks (handled in Admin::hasPermission).
     *
     * Usage: ->middleware('check_permission:view_users')
     *        ->middleware('check_permission:delete_users,edit_users') // any of these
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string  ...$permissions  One or more permission names (OR logic)
     * @return mixed
     */
    public function handle($request, Closure $next, ...$permissions)
    {
        $admin = Auth::guard('admin')->user();

        if (!$admin) {
            \Log::warning("CheckPermission: No admin user found.");
            if ($request->ajax()) {
                return response()->json(['error' => 'Oturum süresi doldu'], 401);
            }
            return redirect()->route('admin.login');
        }

        if (config('app.debug')) {
            \Log::debug("CheckPermission: Admin ID: " . $admin->id . ", required: " . implode(', ', $permissions));
        }

        // Check if admin has ANY of the required permissions (OR logic)
        foreach ($permissions as $permission) {
            if ($admin->hasPermission($permission)) {
                return $next($request);
            }
        }

        \Log::warning("CheckPermission: Access DENIED. Admin ID: " . $admin->id . " does NOT have any of: " . implode(', ', $permissions));

        // No permission matched
        if ($request->ajax()) {
            return response()->json(['error' => 'Bu işlem için yetkiniz bulunmamaktadır.'], 403);
        }

        return response()->view('admin.errors.401', [], 403);
    }
}
PHP
,
        'app/Http/Middleware/AllowedRoles.php' => <<<'PHP'
<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Log;
use Auth;
use App\Role;

class AllowedRoles
{
    /**
     * Handle an incoming request.
     *
     * If specific roles are passed, check against those.
     * If no roles specified, allow any admin with an active role.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string[]  ...$roles
     * @return mixed
     */
    public function handle($request, Closure $next, ...$roles)
    {
        $admin = Auth::guard('admin')->user();

        if (config('app.debug')) {
            Log::debug("AllowedRoles: Checking access for Admin ID: " . ($admin ? $admin->id : 'GUEST') . ", roles: " . json_encode($roles));
        }

        if (!$admin) {
            Log::warning("AllowedRoles: Access DENIED (No admin user found).");
            if ($request->ajax()) {
                return response()->json(['error' => 'Oturum süresi doldu'], 401);
            }
            return redirect()->route('admin.login');
        }

        // Super Admin and Managers always pass this check
        if ($admin->hasRole('SUPER_ADMIN') || $admin->is_manager) {
            return $next($request);
        }

        // If no specific roles required, allow any admin with an active role
        if (empty($roles)) {
            $role = $admin->role()->first();
            if ($role && $role->is_active) {
                return $next($request);
            }
            Log::warning("AllowedRoles: Access DENIED (No specific roles required but admin has no active role). Admin ID: " . $admin->id);
        } else {
            // Check if admin has any of the specified roles
            if ($admin && $admin->hasRole($roles)) {
                return $next($request);
            }
            Log::warning("AllowedRoles: Access DENIED (Admin does not have required role(s): " . json_encode($roles) . "). Admin ID: " . $admin->id);

            // Fallback for custom active roles on "general" routes (SUB_ADMIN etc)
            $role = ($admin) ? $admin->role()->first() : null;
            if ($role && $role->is_active && !$role->is_system) {
                if (is_array($roles) && in_array('SUB_ADMIN', $roles)) {
                    return $next($request);
                }
                if ($roles == 'SUB_ADMIN') {
                    return $next($request);
                }
            }

            // Also check: if the role is active and exists in DB, allow through
            $role = $admin->role()->first();
            if ($role && $role->is_active) {
                $activeRoleNames = Role::where('is_active', 1)->pluck('role_name')->toArray();
                if (in_array($role->role_name, $activeRoleNames)) {
                    return $next($request);
                }
            }
        }

        if ($request->ajax()) {
            return response()->json(['error' => 'Yetkisiz Erişim'], 401);
        }

        return response()->view('admin.errors.401', [], 401);
    }
}
PHP
,
        'app/Scopes/IsActiveScope.php' => <<<'PHP'
<?php

namespace App\Scopes;

use Auth;
use App;
use Illuminate\Database\Eloquent\Scope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class IsActiveScope implements Scope
{

    /**
     * Apply the scope to a given Eloquent query builder.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $builder
     * @param  \Illuminate\Database\Eloquent\Model  $model
     * @return void
     */
    public function apply(Builder $builder, Model $model)
    {
        $user = Auth::guard('admin')->user() ?? (Auth::check() ? Auth::user() : null);
        if ($user && method_exists($user, 'hasRole') && ($user->hasRole('SUPER_ADMIN') || $user->hasRole('SUB_ADMIN'))) {
            return;
        }
        $builder->where('is_active', '=', '1');
    }

}
PHP
,
        'app/Scopes/LangScope.php' => <<<'PHP'
<?php

namespace App\Scopes;

use Auth;
use App;
use Illuminate\Database\Eloquent\Scope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class LangScope implements Scope
{

    /**
     * Apply the scope to a given Eloquent query builder.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $builder
     * @param  \Illuminate\Database\Eloquent\Model  $model
     * @return void
     */
    public function apply(Builder $builder, Model $model)
    {
        $user = Auth::guard('admin')->user() ?? (Auth::check() ? Auth::user() : null);
        if ($user && method_exists($user, 'hasRole') && ($user->hasRole('SUPER_ADMIN') || $user->hasRole('SUB_ADMIN'))) {
            return;
        }
        $builder->where('lang', 'like', \App::getLocale());
    }

}
PHP
,
    ];

    foreach ($files as $relPath => $content) {
        $path = $root . '/' . $relPath;
        if (!is_dir(dirname($path))) {
            say("Atlanıyor (klasör yok): {$relPath}", $log);
            continue;
        }
        if (file_put_contents($path, $content) !== false) {
            say("Yazıldı: {$relPath}", $log);
        } else {
            say("HATA yazılamadı: {$relPath}", $log);
        }
    }

    // Sidebar: reports.view -> view_reports; CRM view_crm; Yönetim bloğu view_crm/manage_campaigns; Kampanya manage_campaigns
    $sidebarPath = $root . '/resources/views/admin/shared/sidebar.blade.php';
    if (is_file($sidebarPath)) {
        $sidebarContent = file_get_contents($sidebarPath);
        $newSidebar = str_replace("hasPermission('reports.view')", "hasPermission('view_reports')", $sidebarContent);
        // Yönetim bloğu: role/security/crm/campaign izinleriyle de açılsın
        $yonetimOld = "APAuthHelp::hasPermission('view_settings') || APAuthHelp::hasPermission('manage_admins'))";
        $yonetimNew = "APAuthHelp::hasPermission('view_settings') || APAuthHelp::hasPermission('manage_admins') || APAuthHelp::hasPermission('manage_roles') || APAuthHelp::hasPermission('view_crm') || APAuthHelp::hasPermission('manage_security') || APAuthHelp::hasPermission('manage_campaigns'))";
        if (strpos($newSidebar, $yonetimNew) === false && strpos($newSidebar, $yonetimOld) !== false) {
            $newSidebar = str_replace($yonetimOld, $yonetimNew, $newSidebar);
        }
        // Personel Takip (CRM) @if: manage_admins -> view_crm
        $crmIfOld = "            @if(APAuthHelp::check(['SUPER_ADMIN']) || APAuthHelp::hasPermission('manage_admins'))\n                <li class=\"nav-item {{ (request()->is('admin/crm*')) ? 'active' : '' }}\">";
        $crmIfNew = "            @if(APAuthHelp::check(['SUPER_ADMIN']) || APAuthHelp::hasPermission('view_crm'))\n                <li class=\"nav-item {{ (request()->is('admin/crm*')) ? 'active' : '' }}\">";
        if (strpos($newSidebar, $crmIfNew) === false && strpos($newSidebar, $crmIfOld) !== false) {
            $newSidebar = str_replace($crmIfOld, $crmIfNew, $newSidebar);
        }
        // Kampanya: SUPER_ADMIN bloğundan çıkar, manage_campaigns ile göster; Cache sadece SUPER_ADMIN
        $kampanyaBlockOld = "            @if(APAuthHelp::check(['SUPER_ADMIN']) || APAuthHelp::hasPermission('manage_settings'))\n                <li class=\"nav-item {{ (request()->is('admin/security*')) ? 'active' : '' }}\">\n                    <a href=\"{{ route('admin.security.index') }}\" class=\"nav-link\">\n                        <i class=\"icon-shield\"></i>\n                        <span class=\"title\">Güvenlik Merkezi</span>\n                    </a>\n                </li>\n                @if(APAuthHelp::check(['SUPER_ADMIN']))\n                    <li class=\"nav-item {{ (request()->is('admin/campaigns*')) ? 'active' : '' }}\">\n                        <a href=\"{{ route('admin.campaign.index') }}\" class=\"nav-link\">\n                            <i class=\"icon-envelope\"></i>\n                            <span class=\"title\">E-posta Kampanyaları</span>\n                        </a>\n                    </li>\n                    <li class=\"nav-item\">\n                        <a href=\"{{ route('admin.clear.cache') }}\" class=\"nav-link\">\n                            <i class=\"icon-refresh\"></i>\n                            <span class=\"title\">Cache Temizle</span>\n                        </a>\n                    </li>\n                @endif\n            @endif";
        $kampanyaBlockNew = "            @if(APAuthHelp::check(['SUPER_ADMIN']) || APAuthHelp::hasPermission('manage_security'))\n                <li class=\"nav-item {{ (request()->is('admin/security*')) ? 'active' : '' }}\">\n                    <a href=\"{{ route('admin.security.index') }}\" class=\"nav-link\">\n                        <i class=\"icon-shield\"></i>\n                        <span class=\"title\">Güvenlik Merkezi</span>\n                    </a>\n                </li>\n            @endif\n            @if(APAuthHelp::check(['SUPER_ADMIN']) || APAuthHelp::hasPermission('manage_campaigns'))\n                <li class=\"nav-item {{ (request()->is('admin/campaigns*')) ? 'active' : '' }}\">\n                    <a href=\"{{ route('admin.campaign.index') }}\" class=\"nav-link\">\n                        <i class=\"icon-envelope\"></i>\n                        <span class=\"title\">E-posta Kampanyaları</span>\n                    </a>\n                </li>\n            @endif\n            @if(APAuthHelp::check(['SUPER_ADMIN']))\n                <li class=\"nav-item\">\n                    <a href=\"{{ route('admin.clear.cache') }}\" class=\"nav-link\">\n                        <i class=\"icon-refresh\"></i>\n                        <span class=\"title\">Cache Temizle</span>\n                    </a>\n                </li>\n            @endif";
        if (strpos($newSidebar, "hasPermission('manage_campaigns')") !== false && strpos($newSidebar, 'E-posta Kampanyaları') !== false) {
            say('Sidebar: Kampanya/Cache bloğu zaten güncel.', $log);
        } elseif (strpos($newSidebar, $kampanyaBlockOld) !== false) {
            $newSidebar = str_replace($kampanyaBlockOld, $kampanyaBlockNew, $newSidebar);
        }
        if ($newSidebar !== $sidebarContent) {
            file_put_contents($sidebarPath, $newSidebar);
            say('Yazıldı: resources/views/admin/shared/sidebar.blade.php', $log);
        } else {
            say('Sidebar: zaten güncel veya metin bulunamadı.', $log);
        }
    } else {
        say('Atlanıyor (dosya yok): sidebar.blade.php', $log);
    }

    // Company route: list-applied-users satırına yetki ekle
    $companyPath = $root . '/routes/admin_routes/company.php';
    if (is_file($companyPath)) {
        $companyContent = file_get_contents($companyPath);
        $newLine = "Route::get('list-applied-users/{job_id}', array_merge(['uses' => 'Admin\\CompanyController@listAppliedUsers'], \$all_users))->name('admin.list.applied.users')->middleware('check_permission:view_companies,view_jobs');";
        if (strpos($companyContent, 'check_permission:view_companies,view_jobs') !== false && strpos($companyContent, 'list-applied-users') !== false) {
            say('Company route: list-applied-users zaten güncel.', $log);
        } else {
            $oldLine = "Route::get('list-applied-users/{job_id}', 'Admin\\CompanyController@listAppliedUsers')->name('admin.list.applied.users');";
            $altOld = "Route::get('list-applied-users/{job_id}', 'Admin\CompanyController@listAppliedUsers')->name('admin.list.applied.users');";
            if (strpos($companyContent, $oldLine) !== false) {
                $companyContent = str_replace($oldLine, $newLine, $companyContent);
                file_put_contents($companyPath, $companyContent);
                say('Yazıldı: routes/admin_routes/company.php (list-applied-users yetkisi)', $log);
            } elseif (strpos($companyContent, $altOld) !== false) {
                $companyContent = str_replace($altOld, $newLine, $companyContent);
                file_put_contents($companyPath, $companyContent);
                say('Yazıldı: routes/admin_routes/company.php (list-applied-users yetkisi)', $log);
            } else {
                say('Company route: list-applied-users satırı farklı formatta, manuel kontrol edin.', $log);
            }
        }
    } else {
        say('Atlanıyor (dosya yok): company.php', $log);
    }

    // Admin.php: Müdür (is_manager) CRM izinlerinde süper admin gibi, takipten muaf
    $adminModelPath = $root . '/app/Admin.php';
    if (is_file($adminModelPath)) {
        $adminContent = file_get_contents($adminModelPath);
        if (strpos($adminContent, 'Personel müdürü CRM') !== false) {
            say('Admin.php: Müdür CRM izni zaten güncel.', $log);
        } else {
            $oldBlock = "        if (\$role->role_name == 'SUPER_ADMIN') {\n            return true;\n        }\n        return \$role->hasPermission(\$permission);";
            $newBlock = "        if (\$role->role_name == 'SUPER_ADMIN') {\n            return true;\n        }\n        // Personel müdürü CRM'de süper admin gibi: tam CRM erişimi, takipten muaf\n        if (\$this->is_manager && in_array(\$permission, ['view_crm', 'manage_crm'], true)) {\n            return true;\n        }\n        return \$role->hasPermission(\$permission);";
            $adminContent = str_replace($oldBlock, $newBlock, $adminContent);
            if ($adminContent !== file_get_contents($adminModelPath)) {
                file_put_contents($adminModelPath, $adminContent);
                say('Yazıldı: app/Admin.php (müdür CRM izni)', $log);
            } else {
                say('Admin.php: hasPermission bloğu farklı formatta, manuel ekleyin.', $log);
            }
        }
    } else {
        say('Atlanıyor (dosya yok): app/Admin.php', $log);
    }

    // admin_layout.blade.php: Müdür (is_manager) durum paneli ve zorunlu modal'dan muaf; role null-safe
    $layoutPath = $root . '/resources/views/admin/layouts/admin_layout.blade.php';
    if (is_file($layoutPath)) {
        $layoutContent = file_get_contents($layoutPath);
        $updated = false;
        $newIfSafe = "Auth::guard('admin')->check() && Auth::guard('admin')->user()->role && Auth::guard('admin')->user()->role->role_name != 'SUPER_ADMIN' && !Auth::guard('admin')->user()->is_manager)";
        if (strpos($layoutContent, "user()->role &&") !== false && strpos($layoutContent, "!Auth::guard('admin')->user()->is_manager)") !== false) {
            say('admin_layout.blade.php: Müdür muafiyeti ve null-safe zaten var.', $log);
        } else {
            $oldWithManager = "Auth::guard('admin')->check() && Auth::guard('admin')->user()->role->role_name != 'SUPER_ADMIN' && !Auth::guard('admin')->user()->is_manager)";
            $oldWithoutManager = "Auth::guard('admin')->check() && Auth::guard('admin')->user()->role->role_name != 'SUPER_ADMIN')";
            if (strpos($layoutContent, $oldWithManager) !== false) {
                $layoutContent = str_replace($oldWithManager, $newIfSafe, $layoutContent);
                $updated = true;
            } elseif (strpos($layoutContent, $oldWithoutManager) !== false) {
                $layoutContent = str_replace($oldWithoutManager, $newIfSafe, $layoutContent);
                $updated = true;
            }
        }
        if (strpos($layoutContent, "restore_crm_sta") !== false && strpos($layoutContent, "getItem('restore_crm_status')") === false) {
            $layoutContent = preg_replace("/getItem\('restore_crm_sta\s+tus'\)/", "getItem('restore_crm_status')", $layoutContent);
            $updated = true;
        }
        if ($updated) {
            file_put_contents($layoutPath, $layoutContent);
            say('Yazıldı: resources/views/admin/layouts/admin_layout.blade.php (müdür durum muafiyeti)', $log);
        }
    } else {
        say('Atlanıyor (dosya yok): admin_layout.blade.php', $log);
    }

    say('=== Yetkilendirme güncellemesi tamamlandı. ===', $log);
    say('Güvenlik için bu dosyayı (update_permissions_once.php) sunucudan silin.', $log);

} catch (Throwable $e) {
    say('HATA: ' . $e->getMessage(), $log);
    if (php_sapi_name() !== 'cli' && !$inLaravel) {
        echo htmlspecialchars(implode("\n", $log)) . "\n\n" . htmlspecialchars($e->getTraceAsString());
        echo "\n</pre></body></html>";
        exit(1);
    }
    throw $e;
}

if (php_sapi_name() !== 'cli' && !$inLaravel) {
    echo htmlspecialchars(implode("\n", $log));
    echo "\n\n</pre><p><strong>Güvenlik için bu dosyayı (update_permissions_once.php) sunucudan silin.</strong></p></body></html>";
}
