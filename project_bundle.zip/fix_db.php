<?php

require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);
$response = $kernel->handle(
    $request = Illuminate\Http\Request::capture()
);

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

try {
    echo "Checking schema...\n";
    Schema::table('seo', function (Blueprint $table) {
        if (!Schema::hasColumn('seo', 'slug')) {
            echo "Adding slug...\n";
            $table->string('slug')->nullable()->unique()->after('page_title');
        } else {
            echo "Slug exists.\n";
        }
        if (!Schema::hasColumn('seo', 'route_name')) {
            echo "Adding route_name...\n";
            $table->string('route_name')->nullable()->unique()->after('slug');
        } else {
            echo "route_name exists.\n";
        }
        if (!Schema::hasColumn('seo', 'controller_action')) {
            echo "Adding controller_action...\n";
            $table->string('controller_action')->nullable()->after('route_name');
        } else {
            echo "controller_action exists.\n";
        }
        if (!Schema::hasColumn('seo', 'is_static')) {
            echo "Adding is_static...\n";
            $table->boolean('is_static')->default(0)->after('controller_action');
        } else {
            echo "is_static exists.\n";
        }
    });
    echo "Done.\n";
} catch (\Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    dd($e);
}
