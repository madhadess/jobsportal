@extends('admin.layouts.admin_layout')
@section('content')
<style type="text/css">
    .table td, .table th {
        font-size: 12px;
        line-height: 2.42857 !important;
    }	
</style>
<div class="page-content-wrapper"> 
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content"> 
        <!-- BEGIN PAGE HEADER--> 
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li> <a href="{{ route('admin.home') }}">Ana Sayfa</a> <i class="fa fa-circle"></i> </li>
                <li> <span>Fonksiyonel Alanlar</span> </li>
            </ul>
        </div>
        <!-- END PAGE BAR --> 
        <!-- BEGIN PAGE TITLE-->
        <h3 class="page-title">Fonksiyonel Alan Yönetimi <small>Fonksiyonel Alanlar</small> </h3>
        <!-- END PAGE TITLE--> 
        <!-- END PAGE HEADER-->
        <div class="row">
            <div class="col-md-12"> 
                <!-- Begin: life time stats -->
                <div class="portlet light portlet-fit portlet-datatable bordered">
                    <div class="portlet-title">
                        <div class="caption"> <i class="icon-settings font-dark"></i> <span class="caption-subject font-dark sbold uppercase">Fonksiyonel Alanlar</span> </div>
                        <div class="actions"> <a href="{{ route('create.functional.area') }}" class="btn btn-xs btn-success"><i class="glyphicon glyphicon-plus"></i> Yeni Fonksiyonel Alan Ekle</a> </div>
                    </div>
                    <div class="portlet-body">
                        <div class="table-container">
                            <form method="post" role="form" id="functionalArea-search-form">
                                <table class="table table-striped table-bordered table-hover"  id="functionalAreaDatatableAjax">
                                    <thead>
                                        <tr role="row" class="filter"> 
                                            <td>{!! Form::select('lang', ['' => 'Dil Seçin']+$languages, config('default_lang'), array('id'=>'lang', 'class'=>'form-control')) !!}</td>
                                            <td><input type="text" class="form-control" name="functional_area" id="functional_area" autocomplete="off" placeholder="Fonksiyonel Alan"></td>
                                            <td><select name="is_active" id="is_active"  class="form-control">
                                                    <option value="-1">Durum</option>
                                                    <option value="1" selected="selected">Aktif</option>
                                                    <option value="0">Pasif</option>
                                                </select></td></tr>
                                        <tr role="row" class="heading">                                            
                                            <th>Dil</th>
                                            <th>Fonksiyonel Alan</th>
                                            <th>İşlemler</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END CONTENT BODY --> 
</div>
@endsection
@push('scripts') 
<script>
    $(function () {
        var oTable = $('#functionalAreaDatatableAjax').DataTable({
            processing: true,
            serverSide: true,
            stateSave: true,
            searching: false,
            ajax: {
                url: '{!! route('fetch.data.functional.areas') !!}',
                data: function (d) {
                    d.lang = $('#lang').val();
                    d.functional_area = $('input[name=functional_area]').val();
                    d.is_active = $('#is_active').val();
                }
            }, columns: [
                {data: 'lang', name: 'lang'},
                {data: 'functional_area', name: 'functional_area'},
                {data: 'action', name: 'action', orderable: false, searchable: false}
            ]
        });
        $('#functionalArea-search-form').on('submit', function (e) {
            oTable.draw();
            e.preventDefault();
        });
        $('#lang').on('change', function (e) {
            oTable.draw();
            e.preventDefault();
        });
        $('#functional_area').on('keyup', function (e) {
            oTable.draw();
            e.preventDefault();
        });
        $('#is_active').on('change', function (e) {
            oTable.draw();
            e.preventDefault();
        });
    });
    function deleteFunctionalArea(id, is_default) {
        var msg = 'Emin misiniz?';
        if (is_default == 1) {
            msg = 'Emin misiniz? Varsayılan fonksiyonel alanı siliyorsunuz. Varsayılan olmayan diğer fonksiyonel alanlar da silinecek!';
        }
        if (confirm(msg)) {
            $.post("{{ route('delete.functional.area') }}", {id: id, _method: 'DELETE', _token: '{{ csrf_token() }}'})
                    .done(function (response) {
                        if (response == 'ok')
                        {
                            var table = $('#functionalAreaDatatableAjax').DataTable();
                            table.row('functionalAreaDtRow' + id).remove().draw(false);
                        } else
                        {
                            alert('İşlem başarısız!');
                        }
                    });
        }
    }
    function makeActive(id) {
        $.post("{{ route('make.active.functional.area') }}", {id: id, _method: 'PUT', _token: '{{ csrf_token() }}'})
                .done(function (response) {
                    if (response == 'ok')
                    {
                        var table = $('#functionalAreaDatatableAjax').DataTable();
                        table.row('functionalAreaDtRow' + id).remove().draw(false);
                    } else
                    {
                        alert('İşlem başarısız!');
                    }
                });
    }
    function makeNotActive(id) {
        $.post("{{ route('make.not.active.functional.area') }}", {id: id, _method: 'PUT', _token: '{{ csrf_token() }}'})
                .done(function (response) {
                    if (response == 'ok')
                    {
                        var table = $('#functionalAreaDatatableAjax').DataTable();
                        table.row('functionalAreaDtRow' + id).remove().draw(false);
                    } else
                    {
                        alert('İşlem başarısız!');
                    }
                });
    }
</script> 
@endpush











