<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('occupation_group_id')->nullable()->change();
        });

        Schema::table('service_requests', function (Blueprint $table) {
            $table->string('occupation_group_id')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->unsignedBigInteger('occupation_group_id')->nullable()->change();
        });

        Schema::table('service_requests', function (Blueprint $table) {
            $table->unsignedBigInteger('occupation_group_id')->nullable()->change();
        });
    }
};
