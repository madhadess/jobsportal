<?php

namespace App\Services;

use App\ServiceRequest;
use App\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class MatchingService
{
    /**
     * Attempt to find and assign a personnel to a service request.
     *
     * @param ServiceRequest $request
     * @return User|null
     */
    public function findMatch(ServiceRequest $request)
    {
        Log::info("Starting matching for Request #{$request->request_number}");

        // 1. Get Initial Candidates
        // - Role: Personnel (Assuming role check handled by is_eligible_for_auto_assignment logic or other scope)
        // - Verified
        // - Active
        // - Eligible for auto assignment
        $candidates = User::where('is_active', 1)
            ->where('verified', 1)
            ->where('is_eligible_for_auto_assignment', 1)
            ->whereIn('user_type', ['personnel', 'caregiver'])
            ->get();

        Log::info("Initial candidates count: " . $candidates->count());

        // 2. Filter Candidates
        $filteredCandidates = $candidates->filter(function ($user) use ($request) {
            return $this->passesFilters($user, $request);
        });

        Log::info("Filtered candidates count: " . $filteredCandidates->count());

        if ($filteredCandidates->isEmpty()) {
            return null;
        }

        // 3. Score Candidates
        $scoredCandidates = $filteredCandidates->map(function ($user) use ($request) {
            $user->match_score = $this->calculateScore($user, $request);
            return $user;
        });

        // 4. Sort by Score (Desc)
        $bestMatch = $scoredCandidates->sortByDesc('match_score')->first();

        Log::info("Best match found: User ID {$bestMatch->id} with Score: {$bestMatch->match_score}");

        return $bestMatch;
    }

    /**
     * Check if a user passes all hard constraints.
     */
    protected function passesFilters(User $user, ServiceRequest $request)
    {
        // Filter 1: Location
        // Assume work_locations is array of district IDs or City IDs
        // $request->customer_district / $request->customer_city
        if (!empty($user->work_locations)) {
            // Simplified check: if work_locations contains the request district ID
            // Assuming customer_district stores the ID. If it stores name, we'd need mapping.
            // Based on earlier controller code, request->customer_district comes from select value, likely ID.
            if (!in_array($request->customer_district, $user->work_locations) && !in_array($request->customer_city, $user->work_locations)) {
                return false;
            }
        }

        // Filter 2: Service Type
        // If user has specific services restricted
        if (!empty($user->service_types)) {
            if (!in_array($request->service_id, $user->service_types)) {
                return false;
            }
        }

        // Filter 3: Capacity
        // Check active tasks vs max daily tasks
        // This is a simplified check. Real check should see if they have a task ON THAT DAY.
        // For 'tam_gun' (8 hours), usually 1 task per day.

        $tasksOnDate = ServiceRequest::where('matched_personnel_id', $user->id)
            ->where('preferred_date', $request->preferred_date)
            ->where('status', '!=', ServiceRequest::STATUS_CANCELLED)
            ->count();

        if ($tasksOnDate >= $user->max_daily_tasks) {
            return false;
        }

        // Filter 4: Availability Calendar
        $preferredDate = Carbon::parse($request->preferred_date);
        $dayOfWeek = strtolower($preferredDate->format('l')); // monday, tuesday, etc.
        $calendar = $user->getAvailabilitySchedule();

        if (!isset($calendar[$dayOfWeek]) || !$calendar[$dayOfWeek]['active']) {
            return false;
        }

        // Time check
        if ($request->preferred_time) {
            // Handle both H:i and H:i:s
            try {
                $requestTime = Carbon::createFromFormat('H:i', $request->preferred_time);
            } catch (\Exception $e) {
                $requestTime = Carbon::createFromFormat('H:i:s', $request->preferred_time);
            }

            $startTime = Carbon::createFromFormat('H:i', $calendar[$dayOfWeek]['start']);
            $endTime = Carbon::createFromFormat('H:i', $calendar[$dayOfWeek]['end']);

            if ($requestTime->lt($startTime) || $requestTime->gt($endTime)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Calculate a matching score (0-100).
     */
    protected function calculateScore(User $user, ServiceRequest $request)
    {
        $score = 0;

        // 1. Rating (30%)
        // Normalized 5.0 -> 30 points
        $ratingScore = ($user->average_rating / 5) * 30;
        $score += $ratingScore;

        // 2. Location (30%)
        // If exact district match -> 30, if just city match -> 15 (simplified)
        if (in_array($request->customer_district, $user->work_locations ?? [])) {
            $score += 30;
        } elseif (in_array($request->customer_city, $user->work_locations ?? [])) {
            $score += 15;
        }

        // 3. Availability / Fairness (20%)
        // Prioritize those who haven't worked recently
        if (!$user->last_task_date) {
            $score += 20; // boost for new/idle
        } else {
            $daysSince = Carbon::parse($user->last_task_date)->diffInDays(now());
            // Cap at 20 points (e.g., if idle for > 10 days, full score)
            $score += min($daysSince * 2, 20);
        }

        // 4. Load Balancing (20%)
        // Less active tasks = Higher score
        // e.g., max 5 active tasks. 
        // 0 active -> 20pts
        // 5 active -> 0pts
        $loadFactor = max(0, 5 - $user->current_active_tasks);
        $score += ($loadFactor / 5) * 20;

        return $score;
    }

    /**
     * Assign the request to the user.
     */
    public function assign(ServiceRequest $request, User $user)
    {
        // Update Request
        $request->matched_personnel_id = $user->id;
        $request->automation_status = 'matched';
        // $request->status = 'approved'; // Or keep pending until personnel accepts? Plan says "Automatic assignment"
        // Let's assume automatic approval for now to remove manual step
        $request->status = 'approved';
        $request->approved_at = now();
        $request->save();

        // Update User
        $user->increment('current_active_tasks');
        $user->last_task_date = now();
        $user->save();

        return true;
    }
}
