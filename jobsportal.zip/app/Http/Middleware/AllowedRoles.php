<?php

namespace App\Http\Middleware;

use Closure;
use Auth;
use App\Role;

class AllowedRoles
{
    /**
     * Handle an incoming request.
     *
     * If specific roles are passed, check against those.
     * If no roles specified, allow any admin with an active role.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string[]  ...$roles
     * @return mixed
     */
    public function handle($request, Closure $next, ...$roles)
    {
        $admin = Auth::guard('admin')->user();

        if (!$admin) {
            if ($request->ajax()) {
                return response()->json(['error' => 'Oturum süresi doldu'], 401);
            }
            return redirect()->route('admin.login');
        }

        // If no specific roles required, allow any admin with an active role
        if (empty($roles)) {
            $role = $admin->role()->first();
            if ($role && $role->is_active) {
                return $next($request);
            }
        } else {
            // Check if admin has any of the specified roles
            if ($admin->hasRole($roles)) {
                return $next($request);
            }

            // Also check: if the role is active and exists in DB, allow through
            // This catches dynamically created roles not in the hardcoded list
            $role = $admin->role()->first();
            if ($role && $role->is_active) {
                // Check if this role_name is in the active roles table
                $activeRoleNames = Role::where('is_active', 1)->pluck('role_name')->toArray();
                if (in_array($role->role_name, $activeRoleNames)) {
                    return $next($request);
                }
            }
        }

        if ($request->ajax()) {
            return response()->json(['error' => 'Yetkisiz Erişim'], 401);
        }

        return response()->view('admin.errors.401', [], 401);
    }
}
