<?php

namespace App\Http\Controllers;

use Auth;
use App\User;
use App\ServiceRequest;
use App\Service;
use App\State;
use App\City;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Helpers\DataArrayHelper;

class PersonnelAutomationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function myAssignments()
    {
        $user = Auth::user();
        $assignments = ServiceRequest::where('matched_personnel_id', $user->id)
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('user.assignments', compact('assignments'));
    }

    public function workPreferences()
    {
        $user = Auth::user();
        $services = Service::active()->get();
        $states = State::where('country_id', 805)->get(); // Turkey (ID: 805)

        return view('user.work_preferences', compact('user', 'services', 'states'));
    }

    public function updatePreferences(Request $request)
    {
        $user = Auth::user();

        $user->is_eligible_for_auto_assignment = $request->has('is_eligible_for_auto_assignment');
        $user->service_types = $request->input('service_types', []);
        $user->work_locations = $request->input('work_locations', []);
        $user->max_daily_tasks = $request->input('max_daily_tasks', 5);

        $user->save();

        flash(__('Çalışma tercihleriniz başarıyla güncellendi.'))->success();
        return redirect()->route('personnel.preferences');
    }
    public function assignmentDetails($id)
    {
        $user = Auth::user();
        $assignment = ServiceRequest::where('matched_personnel_id', $user->id)
            ->where('id', $id)
            ->firstOrFail();

        return view('user.assignment_details', compact('assignment'));
    }

    public function acceptAssignment($id)
    {
        $user = Auth::user();
        $assignment = ServiceRequest::where('matched_personnel_id', $user->id)
            ->where('id', $id)
            ->where('automation_status', 'matched')
            ->firstOrFail();

        $assignment->automation_status = 'accepted';
        $assignment->save();

        flash(__('İşi başarıyla kabul ettiniz. Teşekkürler!'))->success();
        return redirect()->route('personnel.assignment_details', $id);
    }
}
