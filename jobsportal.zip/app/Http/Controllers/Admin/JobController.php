<?php

namespace App\Http\Controllers\Admin;

use Auth;
use DB;
use Input;
use Redirect;
use App\Job;
use App\JobApply;
use App\Company;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use DataTables;
use App\Http\Controllers\Controller;
use App\Traits\JobTrait;
use App\Helpers\MiscHelper;
use App\Helpers\DataArrayHelper;
use Illuminate\Support\Str;
use Mail;
use App\Mail\JobApprovalMailable;

class JobController extends Controller
{

    use JobTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function indexJobs()
    {
        $companies = DataArrayHelper::companiesArray();
        $countries = DataArrayHelper::defaultCountriesArray();
        return view('admin.job.index')
            ->with('companies', $companies)
            ->with('countries', $countries);
    }



    public function fetchJobsData(Request $request)
    {
        $jobs = Job::select([
            'jobs.id',
            'jobs.company_id',
            'jobs.title',
            'jobs.description',
            'jobs.country_id',
            'jobs.state_id',
            'jobs.city_id',
            'jobs.is_freelance',
            'jobs.career_level_id',
            'jobs.salary_from',
            'jobs.salary_to',
            'jobs.hide_salary',
            'jobs.functional_area_id',
            'jobs.job_type_id',
            'jobs.job_shift_id',
            'jobs.num_of_positions',
            'jobs.gender_id',
            'jobs.expiry_date',
            'jobs.degree_level_id',
            'jobs.job_experience_id',
            'jobs.is_active',
            'jobs.is_featured',
        ]);
        return Datatables::of($jobs)
            ->filter(function ($query) use ($request) {
                if ($request->has('company_id') && !empty($request->company_id)) {
                    $query->where('jobs.company_id', '=', "{$request->get('company_id')}");
                }
                if ($request->has('title') && !empty($request->title)) {
                    $query->where('jobs.title', 'like', "%{$request->get('title')}%");
                }
                if ($request->has('description') && !empty($request->description)) {
                    $query->where('jobs.description', 'like', "%{$request->get('description')}%");
                }
                if ($request->has('country_id') && !empty($request->country_id)) {
                    $query->where('jobs.country_id', '=', "{$request->get('country_id')}");
                }
                if ($request->has('state_id') && !empty($request->state_id)) {
                    $query->where('jobs.state_id', '=', "{$request->get('state_id')}");
                }
                if ($request->has('city_id') && !empty($request->city_id)) {
                    $query->where('jobs.city_id', '=', "{$request->get('city_id')}");
                }
                if ($request->has('is_active') && $request->is_active != -1) {
                    $query->where('jobs.is_active', '=', "{$request->get('is_active')}");
                }
                if ($request->has('is_featured') && $request->is_featured != -1) {
                    $query->where('jobs.is_featured', '=', "{$request->get('is_featured')}");
                }
            })
            ->addColumn('company_id', function ($jobs) {
                return $jobs->getCompany('name');
            })
            ->addColumn('city_id', function ($jobs) {
                return $jobs->getCity('city') . '(' . $jobs->getState('state') . '-' . $jobs->getCountry('country') . ')';
            })
            ->addColumn('description', function ($jobs) {
                return strip_tags(Str::limit($jobs->description, 50, '...'));
            })
            ->addColumn('action', function ($jobs) {
                $admin = Auth::guard('admin')->user();

                $activeTxt = __('Aktif Yap');
                $activeHref = 'makeActive(' . $jobs->id . ');';
                $activeIcon = 'square-o';
                if ((int) $jobs->is_active == 1) {
                    $activeTxt = __('Pasif Yap');
                    $activeHref = 'makeNotActive(' . $jobs->id . ');';
                    $activeIcon = 'check-square-o';
                }

                $featuredTxt = __('Öne Çıkar');
                $featuredHref = 'makeFeatured(' . $jobs->id . ');';
                $featuredIcon = 'square-o';
                if ((int) $jobs->is_featured == 1) {
                    $featuredTxt = __('Öne Çıkarımdan Kaldır');
                    $featuredHref = 'makeNotFeatured(' . $jobs->id . ');';
                    $featuredIcon = 'check-square-o';
                }

                $list_candidates = JobApply::where('job_id', '=', $jobs->id)->count();

                $actions = '<div class="btn-group">
                    <button class="btn blue dropdown-toggle" data-toggle="dropdown" aria-expanded="false">' . __('İşlemler') . ' <i class="fa fa-angle-down"></i></button>
                    <ul class="dropdown-menu">';

                if ($admin->hasPermission('edit_jobs')) {
                    $actions .= '<li><a href="' . route('edit.job', ['id' => $jobs->id]) . '"><i class="fa fa-pencil" aria-hidden="true"></i>' . __('Düzenle') . '</a></li>';
                }
                if ($admin->hasPermission('delete_jobs')) {
                    $actions .= '<li><a href="javascript:void(0);" onclick="deleteJob(' . $jobs->id . ', ' . $jobs->is_default . ');"><i class="fa fa-trash-o" aria-hidden="true"></i>' . __('Sil') . '</a></li>';
                }

                $actions .= '<li><a href="' . route('public.job', ['id' => $jobs->id]) . '"><i class="fa fa-eye" aria-hidden="true"></i>' . __('İş İlanı Detayı Görüntüle') . '</a></li>';
                $actions .= '<li><a href="' . route('admin.list.applied.users', [$jobs->id]) . '"><i class="fa fa-users" aria-hidden="true"></i>' . __('Başvuranları Listele') . ' <span class="badge badge-primary">' . $list_candidates . '</span></a></li>';

                if ($admin->hasPermission('approve_jobs')) {
                    $actions .= '<li><a href="javascript:void(0);" onClick="' . $activeHref . '" id="onclickActive' . $jobs->id . '"><i class="fa fa-' . $activeIcon . '" aria-hidden="true"></i>' . $activeTxt . '</a></li>';
                }
                if ($admin->hasPermission('feature_jobs')) {
                    $actions .= '<li><a href="javascript:void(0);" onClick="' . $featuredHref . '" id="onclickFeatured' . $jobs->id . '"><i class="fa fa-' . $featuredIcon . '" aria-hidden="true"></i>' . $featuredTxt . '</a></li>';
                }

                $actions .= '</ul></div>';
                return $actions;
            })
            ->rawColumns(['action', 'company_id', 'city_id', 'description'])
            ->setRowId(function ($jobs) {
                return 'jobDtRow' . $jobs->id;
            })
            ->make(true);
    }

    public function deleteJobs(Request $request)
    {

        $ids = $request->input('ids');
        flash(__('İş silindi!'))->success();
        flash(__('İş güncellendi!'))->success();
        $arr = explode(',', $ids);
        $user = Job::whereIn('id', $arr)->delete();
        echo 'done';

    }
    public function makeActiveJob(Request $request)
    {
        $id = $request->input('id');
        try {
            $job = Job::findOrFail($id);
            $job->is_active = 1;
            $job->update();
            Mail::send(new JobApprovalMailable($job));
            echo 'ok';
        } catch (ModelNotFoundException $e) {
            echo 'notok';
        }
    }

    public function makeNotActiveJob(Request $request)
    {
        $id = $request->input('id');
        try {
            $job = Job::findOrFail($id);
            $job->is_active = 0;
            $job->update();
            echo 'ok';
        } catch (ModelNotFoundException $e) {
            echo 'notok';
        }
    }

    public function makeFeaturedJob(Request $request)
    {
        $id = $request->input('id');
        try {
            $job = Job::findOrFail($id);
            $job->is_featured = 1;
            $job->update();
            echo 'ok';
        } catch (ModelNotFoundException $e) {
            echo 'notok';
        }
    }

    public function makeNotFeaturedJob(Request $request)
    {
        $id = $request->input('id');
        try {
            $job = Job::findOrFail($id);
            $job->is_featured = 0;
            $job->update();
            echo 'ok';
        } catch (ModelNotFoundException $e) {
            echo 'notok';
        }
    }

}
