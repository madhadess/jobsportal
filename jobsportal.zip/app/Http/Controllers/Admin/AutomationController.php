<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\ServiceRequest;
use App\User;
use Illuminate\Http\Request;

class AutomationController extends Controller
{
    public function index()
    {
        $stats = [
            'total_pending' => ServiceRequest::where('automation_status', 'pending_matching')->count(),
            'total_matched' => ServiceRequest::where('automation_status', 'matched')->count(),
            'total_failed' => ServiceRequest::where('automation_status', 'failed')->count(),
        ];

        $recentMatchings = ServiceRequest::with(['user', 'service', 'matchedPersonnel'])
            ->whereNotNull('automation_status')
            ->orderBy('updated_at', 'desc')
            ->paginate(20);

        return view('admin.automation.index', compact('stats', 'recentMatchings'));
    }

    public function personnelStats()
    {
        $personnel = User::where('is_eligible_for_auto_assignment', 1)
            ->withCount([
                'matchedRequests' => function ($query) {
                    $query->where('status', 'completed');
                }
            ])
            ->orderBy('average_rating', 'desc')
            ->paginate(20);

        return view('admin.automation.personnel', compact('personnel'));
    }

    public function retryMatching($id)
    {
        $request = ServiceRequest::findOrFail($id);
        $request->automation_status = 'pending_matching';
        $request->matching_attempts = 0;
        $request->save();

        return back()->with('success', 'Talep yeniden eşleştirme kuyruğuna alındı.');
    }
}
