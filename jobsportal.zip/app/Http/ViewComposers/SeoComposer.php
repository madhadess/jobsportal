<?php

namespace App\Http\ViewComposers;

use Illuminate\View\View;
use Illuminate\Support\Facades\Route;
use App\Seo;

class SeoComposer
{
    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view)
    {
        // If 'seo' data is not already passed from the controller
        if (!isset($view->seo)) {
            $routeName = Route::currentRouteName();
            if ($routeName) {
                // Fetch generic SEO for this route
                $seo = Seo::where('route_name', $routeName)->first();
                if ($seo) {
                    $view->with('seo', $seo);
                }
            }
        }
    }
}
